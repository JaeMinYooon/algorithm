
public class ¦����Ȧ�� {
	public static void main(String[] args) {
		solution(4);
		
	}

	static  public String solution(int n) {
	      String answer = "";
	      if(n%2==0)
	    	  answer = "Even";
	      else
	    	  answer = "Odd";
	      return answer;
	}
}
