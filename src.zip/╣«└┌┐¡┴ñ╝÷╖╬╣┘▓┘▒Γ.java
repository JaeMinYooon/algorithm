
public class ���ڿ������ιٲٱ� {

	public static void main(String[] args) {
		String s = "-1234";
		solution(s);
		
	}
	public static int solution(String s) {
	      int answer = 0;
	      answer = Integer.parseInt(s);
	      return answer;
	  }
}
